package com.mycompany.aula;


public class Residencia extends Seguro {
        private String endereco;
        private Integer ano;
        
        public Residencia(String nome, Double valor, String endereco, Integer ano){
        super(nome, valor);
        this.endereco = endereco;
        this.ano = ano;
        }
        public Double valorPremio(){
            Double valor = this.valor;
            Integer diffAno = 2022 - this.ano;
            return valor - 0002*diffAno;
              
        }
        
        
        public String getEndereco(){
            return this.endereco;
        
        
        }
        public void setEndereco(String endereco){
            this.endereco = endereco;
        
        
        }
        public Integer getAno(){
            return this.ano;
        
        
        }
        public void setAno(Integer ano){
            this.ano = ano;
        
        
        }

    
}
