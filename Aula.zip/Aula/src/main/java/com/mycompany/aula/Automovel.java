package com.mycompany.aula;


public class Automovel extends Seguro {
    private Integer ano;
    private String chassi;
    public Automovel(String nome, Double valor, Integer ano, String chassi){
        super(nome, valor);
        this.ano = ano;
        this.chassi = chassi;
    
    
    }
    public Double valorPremio(){
        return (this.valor*0.9) - (0.02*(2022 - this.ano));
            
              
        }
    public Integer getAno(){
            return this.ano;
        
        
    }
    public void setAno(Integer ano){
            this.ano = ano;
        
        
    }
    public String getChassi(){
            return this.chassi;
        
        
    }
    public void setChassi(String chassi){
            this.chassi = chassi;
        
        
    }
    
    
}
