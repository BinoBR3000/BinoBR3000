package com.mycompany.aula;


public class Seguradora {
    public static void main(String[] args){
        
       Vida segVida = new Vida("Adailton", 10000.00, 20);
       segVida.setIdade(20);
    
        System.out.println("Valor do premio: " + segVida.valorPremio());
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
