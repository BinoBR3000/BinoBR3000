package com.mycompany.aula;


public abstract class Seguro {
    protected String nome;
    protected Double valor;
    
    public Seguro(String nome, Double valor) {
        this.nome = nome;
        this.valor = valor;
        
    
    }
    public String getNome() {
        return this.nome;
    
    
   }
    public Double getvalor() {
        return this.valor;
    
    
    }
    public abstract Double valorPremio();
    
   
    public void setNome(String nome) {
        this.nome = nome;
    
    
    
    }
    public void setValor(Double valor){
        this.valor = valor;
    
    
    }
}

