package com.mycompany.aula;


public class Vida extends Seguro {
    private Integer idade;
    
    public Vida(String nome, Double valor, Integer idade) {
        super(nome, valor);
        this.idade = idade;
        
        
        
    
    }
    public Integer getIdade() {
        return this.idade;
        
    
    
    }
    public Double valorPremio(){
        Double valor = this.valor;
        if(this.idade < 50){
            valor += valor*0.1;
        }
        return valor;
    
    
    
    }
    public void setIdade(Integer idade){
        this.idade = idade;
    
    
    }

    
    
}
